package com.bookzy.app.piedpiper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PiedpiperApplication {

	public static void main(String[] args) {
		SpringApplication.run(PiedpiperApplication.class, args);
	}

}
