package com.bookzy.app.piedpiper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PiedpiperApplicationTests {

	@Test
	void contextLoads() {
	}

}
